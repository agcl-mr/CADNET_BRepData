#Author-Gawtam
#Description-Script which changes dimensions and parameters in CAD models as specifiedd in an excel sheet saved as .csv ...

import adsk.core, adsk.fusion, adsk.cam, traceback,os.path

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        des = app.activeProduct
        
        #to get the root component of the active design
        rootComp = des.rootComponent

        #folder to write out the results.
        folder = 'D:/STEP Files/Thin Plates/'

        #get the parameters names to change. (for eg: "Length" and "dia") 
        dialog = ui.createFileDialog()
        dialog.filter = 'Comma Separated Values (*.csv)'
        dialog.initialDirectory = os.path.dirname(os.path.realpath(__file__))
        if dialog.showOpen() != adsk.core.DialogResults.DialogOK:
            return
        
        filename=dialog.filename
        f=open(filename,'r')    
    
        firstLine = f.readline()
        firstLine = firstLine.rstrip('\n')
        paramNames = firstLine.split(',')
        paramNames = paramNames[1:]
              
        #iterate through the value lines.
        line = f.readline()
        while line:
            
            #doc = app.activeDocument
            #des = app.activeProduct
            params = des.allParameters      

            line = line.rstrip('\n')
            values = line.split(',')

            #iterate through the values and change the corresponding parameter.            
            for i in range(1,len(values)):
                param = params.itemByName(paramNames[i-1])
                param.expression = values[i]
                
            rootComp = des.rootComponent

            filename = folder + str(values[0])+ '.stp'
            adsk.doEvents()
                
            # Export the component as STEP.
            exportMgr = des.exportManager
            stepOptions = exportMgr.createSTEPExportOptions(filename)
            stepOptions.geometry = rootComp
            exportMgr.execute(stepOptions)
            line = f.readline()    
            
        
        f.close()     
                
                
        ui.messageBox('Finished.')
    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))